'use strict';

const fs = require('fs')
const express = require('express');
const app = express();

app.get('/', function (req, res) {

  res.send('Lavantapp api');
});
const path = `./haberler/haberler.json` 
app.get('/ekle', function (req,res){

    if (req.query.auth != "ba740ed4754b17e10bb5f57ccc06c1fe"){
        var autherror = {status: "error" , message: "Giriş başarısız." }
        res.send(JSON.stringify(autherror))
    }
    if (req.query.haber == undefined){
   var haberhatajson = {status: "error" , message: "HATA Lütfen Haberi belirtiniz." }   
   res.send(JSON.stringify(haberhatajson))
   return
    } else if (req.query.baslik == undefined){
    var baslikhatajson = {status: "error" , message: "HATA Lütfen baslik belirtiniz." }   
        res.send(JSON.stringify(baslikhatajson))
        return
    } else if (req.query.resim == undefined){
     var resimhatajson = {status: "error" , message: "HATA Lütfen resim belirtiniz." }   
     res.send(JSON.stringify(resimhatajson))
     return
    }
    var data = { baslik : req.query.baslik, haber: req.query.haber, resim: req.query.resim}
    var dataa = JSON.stringify(data)
    fs.writeFile(`haberler/${req.query.baslik}.json`, dataa, function (err) {
        if (err) throw err; 
      });
    res.send(JSON.stringify(data))
})
app.get('/haberler', function (req, res) {
    const data = []
    const dataa = {status: "success", data: []}
    fs.readdir('./haberler/', (plugin, files) => {    
        var jsfiles = files.filter(f => f.split('.').pop() === 'json');
        if (jsfiles.length <= 0) { return res.send(JSON.stringify({"status": "error", "message" : "Haber Bulunamadı"})) }
        jsfiles.forEach((f, i) => {
            data.push(f)
        });
        data.forEach(( i) => {
           const resdata = fs.readFileSync(`./haberler/${i}`,
           {encoding:'utf8', flag:'r'});
          var resdatajson = JSON.parse(resdata)
          dataa.data.push(resdatajson)
        });
 res.send(JSON.stringify(dataa))
});
  });
app.listen(1453, function () {
  console.log('Sunucu çalışıyor...');
});