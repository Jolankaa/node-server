const axios = require('axios')



axios.get('http://localhost:1453/haberler')
  .then(function (response) {
   
    console.log(response.data);
   
  })

